{ ... }:
{
  networking.firewall.enable = true;
}
