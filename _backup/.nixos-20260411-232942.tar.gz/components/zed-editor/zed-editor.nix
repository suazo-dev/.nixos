{
  lib,
  pkgs,
  spec,
  ...
}: {
  environment.systemPackages = lib.mkIf (!spec.facts.headless) [pkgs.zed-editor];

  home-manager.users.${spec.user} = lib.mkIf (!spec.facts.headless) ({config, ...}: {
    xdg.configFile."zed/themes/Catppuccin Black.json".source =
      config.lib.file.mkOutOfStoreSymlink
      "/home/${spec.user}/.nixos/components/zed-editor/dotfiles/Catppuccin Black.json";
  });
}
