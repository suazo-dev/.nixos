{
  components = [
    "net-debug-tools"
  ];
}
