{
  components = [
    "syncthing"
  ];
}
