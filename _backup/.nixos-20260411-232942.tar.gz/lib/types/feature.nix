{
  allowedKeys = [
    "features"
    "components"
  ];
}
